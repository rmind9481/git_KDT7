# -----------------------------------------------------------------------------
# Unit 7 출력 방법 알아보기
# -----------------------------------------------------------------------------

# print(값1, 값2, 값3)  print(변수1, 변수2, 변수3) 

print(1,2,3)
print("hello", "Python")

# sep 로 값 사이에 문자넣기
# sep 는 구분자  print(값1, 값2, sep= "문자 또는 문자열")

print(1,2,3, sep="＠")
print(1,2,3, sep="Lucky")

# 줄바꿈
print(1,2,3, sep='\n')


# end 사용하기
# print 는 기본적으로 출력하는 값 끝에 \n을 붙입니다. 그래서 print를 여러번 사용하면 값이 여러줄에 출력됨

print('a')
print('b')
print('c')

print('a1,b1,c1',end='')
print('a2,b2,c2',end='')
print('a3,b3,c3')



# 연습문제
# 다음 소스코드를 완성해서 날짜와 시간이 출력되게 만드세요

year = 2000
month = 10
day = 27
hour = 11
minute = 43
second =59

print(year,month,day, sep="/",end=" ")
print(hour,minute,second, sep=":")