# -----------------------------------------------------------------------------
# Unit 8 불과 비교, 논리 연산자 알아보기
# -----------------------------------------------------------------------------

# 불은 True , False 로 표현 한다. 1 => True 0 => False 

print(int(True))
print(int(False))


# 비교 연산자 종류
# a > b  a 는 b 보다 크다
# a < b  a 는 b 보다 작다
# a >= b  a 는 b 보다 크거나 같다
# a <= b  a 는 b 보다 작거나 같다
# a == b  a 는 b 보다 같다
# a != b  a 는 b 보다 같지 않다다


a = 10
b = 15

print(f'{a} > {b}  = {a>b}')
print(f'{a} < {b}  = {a<b}')
print(f'{a} >= {b}  = {a>=b}')
print(f'{a} <= {b}  = {a<=b}')
print(f'{a} == {b}  = {a==b}')
print(f'{a} != {b}  = {a!=b}')

# 객체가 같은지 다른지 비교하지
# is, is not 을 쓴다. == 같다, != 같지않다 이미 함수가 있는데 중복되는것 처럼보이지만
# is, in not 은 객체 자체를 비교한다. 
# ==, != 값/데이터 를 비교한다

print(f' == 형태 비교 "1 == 1.0"  {1 == 1.0} { id(1), id(1.0)}')
print(f' is 형태 비교 "1 is 1.0"  {1 is 1.0} { id(1), id(1.0)}')



# 논리 연산자
# and, or, not

print(f"논리 연산자 and = > True and True :{True and True}")
print(f"논리 연산자 and = > True and False :{True and False}")
print(f"논리 연산자 and = > False and False :{False and False}", end="\n\n\n")

print(f"논리 연산자 or = > True or True :{True or True}")
print(f"논리 연산자 or = > True or False :{True or False}")
print(f"논리 연산자 or = > False or False :{False or False}", end="\n\n\n")


print(f"논리 연산자 not = > not True :{not True}")
print(f"논리 연산자 not = > not True :{not False}")


# bool 타입 
print(bool(1))
print(bool(0))


# 연습문제
# 합격 여부 출력하기
# 국어,영어,수학,과학 점수가 한과목이라도 50 점 미만이면 불합격

korean = 92
english = 47
mathematics = 86
science = 81


print(f"현재 점수 국어{korean} 영어{english} 수학{mathematics} 과학{science}")
print( korean >= 50 and english >= 50 and mathematics >= 50 and science >= 50 )