# 01 ~ 010

# 01. 화면에 Hello World 문자열을 출력하세요.

print("HEllo World")


# 02. 화면에 MAry's cosmetics 을 출력하세요.

print(f"Mary's cosmetics")

# 03. 화면에 아래 문장을 출력하세요.
# 신씨가 소리질렀따. "도둑이야".


print('신씨가 소리 질렀다. "도둑이야".')


# 04. 화면에 c:\Windows 를 출력하세요.

print("c:\\Windows")


# 05. 다음 코드를 실행해보고 \t 와 \n의 역할을 설명해보세요.

print("안녕하세요.\n만나서\t\t반갑습니다.")

# \t 글자를 4칸씩 띄워준다. Tab 키
# \n 줄을 바꿔준다.

# 06. 아래 코드의 출력 결과을 예상해 봅시다.
print ("오늘은", "일요일")
# 따옴표 없이 실행행

# 07. print() 함수를 사용하여 다음과 같이 출력하세요.

# naver;kakao;sk;samsung
print('naver;kakao;sk;samsung')


# 08. print() 함수를 사용하여 다음과 같이 출력하세요.

# naver/kakao/sk/samsung

print("naver/kakao/sk/samsung")

#09. 다음 코드를 수정하여 줄바꿈이 없이 출력하세요. 
# (힌트: end='') print 함수는 두 번 사용합니다. 
# 세미콜론 (;)은 한줄에 여러 개의 명령을 작성하기 위해 사용합니다.

print("first",end="");print("second")

#010 연산 결과 출력
# 5/3의 결과를 화면에 출력하세요.

print(f"5/3 의 결과 :{5/3}")